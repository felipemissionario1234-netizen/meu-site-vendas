# Site de Vendas — pronto pra Vercel
Estrutura correta (index.html + styles.css + app.js + /assets).

## Como publicar
1. Suba tudo para um repositório no GitHub.
2. Na Vercel: Import → selecione o repositório → Deploy.

## Personalize
- `styles.css`: cor primária via `--primary`.
- `app.js`: troque `checkoutURL` e `whatsappNumber`.
- `assets/`: troque as imagens pelo seu produto.
